<?php
include("view/aside.php");
include("view/header.php");
?>

        <div class="row2">
            <p class="main-bold-text">
                Thêm mới loại phòng
            </p>
        </div>
    </div>

    <div class="main-body">
    <div class="main-body-group">
        <div class="main-body-1">
            <p class="main-bold-text">Thêm loại phòng mới</p>
        </div>
    </div>
    <form action="" method="">
        <div class="input-group">
            <input type="text" placeholder="Tên loại phòng">
        </div>
        <div class="input-group">
            <textarea name="" id="" rows="7" placeholder="Mô tả"></textarea>
        </div>
        <div class="form-btn">
            <input type="submit" value="Tạo">
            <input type="reset" value="Nhập lại">
        </div>
    </form>