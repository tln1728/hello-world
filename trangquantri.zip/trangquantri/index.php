<?php
include("view/aside.php");
include("view/header.php");
include("view/footer.php");