<main>
    <div class="main-head">
        <div class="row1">
            <div class="btn">
                <button>Trang quản trị</button>
                <button>Trang khách hàng</button>
            </div>
            <span>Hi, <b>Quản trị viên</b></span>
        </div>
