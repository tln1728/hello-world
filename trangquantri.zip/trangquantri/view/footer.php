</main>
<footer>
    <div class="footer-contact">
        <a href="">About</a>
        <a href="">Team</a>
        <a href="">Contact</a>
    </div>
    <div>

    </div>
</footer>
</div>
<!-- end container -->

</body>

</html>