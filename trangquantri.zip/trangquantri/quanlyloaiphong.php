<?php
include("view/aside.php");
include("view/header.php");
?>
        <div class="row2">
            <p class="main-bold-text">
                Tổng quan
            </p>
        </div>
    </div>

<div class="main-body">
    <div class="main-body-group">
        <div class="main-body-1">
            <p class="main-bold-text">Quản lý loại phòng</p>
            <p class="main-light-text">Danh các loại phòng có trên hệ thống</p>
        </div>

        <div class="main-body-2">
            <a href="themloaiphong.php"><button><b>Thêm mới loại phòng</b></button></a>
        </div>
    </div>

    <form action="" method="">
        <div class="search">
            <ion-icon name="search-outline"></ion-icon>
            <input type="text" placeholder="Search...">
        </div>
    </form>


    <div class="table">
        <table>
            <thead>
                <tr>
                    <th>ID Danh mục</th>
                    <th>Tên danh mục</th>
                    <th>Ngày tạo</th>
                    <th>Người tạo</th>
                    <th>Hành động</th>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td>1</td>
                    <td>Phòng đơn</td>
                    <td>2022-11-18 19:19:15</td>
                    <td>Quản trị viên</td>
                    <td><a href=""><button><ion-icon name="settings-sharp"></ion-icon></button></a>
                        <a href=""><button><ion-icon name="trash-sharp"></ion-icon></button></a>
                    </td>
                </tr>
            </tbody>

        </table>
    </div>
</div>